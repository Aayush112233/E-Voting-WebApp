import fs from "fs";


const html = fs.readFileSync('./Pages/EmailPage.html', 'utf8');

export default html;
