import React from "react";
import "../assets/customCss/loader.css";
const Loader = () => {
  return <div class="loader-circle-6"></div>;
};

export default Loader;
