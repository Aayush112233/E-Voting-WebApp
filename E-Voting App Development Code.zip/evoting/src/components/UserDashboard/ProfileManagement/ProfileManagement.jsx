import React from 'react'

const ProfileManagement = () => {
  return (
    <div>Voter Profile</div>
  )
}

export default ProfileManagement