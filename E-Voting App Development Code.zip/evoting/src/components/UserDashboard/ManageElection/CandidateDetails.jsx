import React from 'react'

const CandidateDetails = () => {
  return (
    <div>CandidateDetails</div>
  )
}

export default CandidateDetails